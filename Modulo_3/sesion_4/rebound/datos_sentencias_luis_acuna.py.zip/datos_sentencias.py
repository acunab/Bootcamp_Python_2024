#definimos las variables

a = 8
b = 10.5
c = "ejercicio"

# Creamos un set que contiene las variables

mi_set = { a, b, c}

# Creamos una lista que contiene el set y una variable con el valor lógico False
mi_lista = [mi_set, False]

# Imprimimos la lista en pantalla
print(mi_lista)