# definimos las variables y asignamos los valores

a = 20
b = 30

#realizamos la operación
multiplica = a * b


#imprimimos el resultado

print(multiplica)

