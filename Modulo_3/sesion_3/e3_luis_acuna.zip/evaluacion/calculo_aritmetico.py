import math

# Asignar el valor a la variable y
y = 81

# Calcular la raíz cuadrada utilizando math.sqrt()
resultado = math.sqrt(y)

# Imprimir el resultado
print(resultado)  # Esto imprimirá 9.0