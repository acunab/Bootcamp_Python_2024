# Lista inicial
mi_lista = [5, 20, 15, 20, 25, 50, 20, 5, 18, 15]

# 1. Eliminar elementos duplicados
mi_lista_sin_duplicados = list(set(mi_lista))

# 2. Ordenar la lista en orden ascendente
mi_lista_ordenada = sorted(mi_lista_sin_duplicados)

# Resultado final
print(mi_lista_ordenada)