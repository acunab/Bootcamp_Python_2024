+------------------+
|     Persona      |
+------------------+
| - numero_id: str |
| - nombre: str    |
| - apellido: str  |
+------------------+
| + obtener_datos(): str |
+------------------+

         ▲
         |
         |
+---------------------+
|     Estudiante      |
+---------------------+
| - numero_id: str    |
| - nombre: str       |
| - apellido: str     |
| - codigo_alumno: str|
| - matricula: str    |
+---------------------+
| + obtener_datos(): str |
+---------------------+